module.exports = {
  extends: require.resolve('@umijs/max/stylelint'),
};
