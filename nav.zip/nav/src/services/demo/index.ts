/* eslint-disable */
// 该文件由 OneAPI 自动生成，请勿手动修改！

import * as UserController from './UserController';
export default {
  UserController,
};
